# Software Systems Development
## Kshitij Nigam - 2023202031

This lab contains Python file handling and does Q1 with 5 subparts in one file sequentially.

Also Tabulate is needed to run this program to install it:
```
    pip3 install tabulate
```

To work correctly copy the stock_data.csv file to same directory and run: 

```
    ./2023202031.py
```
