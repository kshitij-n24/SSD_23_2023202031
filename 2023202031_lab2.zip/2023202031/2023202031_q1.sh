#! /bin/bash

read num_test_cases 

read -a arr

for i in ${arr[*]}; 
  do
    chk_even=$(( $i % 2 ))
    if [ $chk_even -ne 0 ]; then
    for (( j=0; j<i; j++ ));
      do
            if [ $i -lt $(( 2*$j+1 )) ]; then
                num_spaces=$(( (2*$j+1) - $i ))
              else
                num_spaces=$(( $i - (2*$j+1) ))
            fi
            
            inst_num_limit=$(( num_spaces/2 ))
            row_arr=()
            idx_row_char=0
            for (( l=0; l<inst_num_limit; l++ ));
              do
                row_arr[$idx_row_char]=" "
                idx_row_char=$(( idx_row_char+1 ))
                echo -ne "idx_l="$idx_row_char
              done
            for (( m=0; m<( 2*j+1 ) ; m++ )); do
                row_arr[$idx_row_char]="*"
                idx_row_char=$(( idx_row_char+1 ))
                echo -ne "\tm="$m
                echo -ne "\tidx_m="$idx_row_char
            done
            for (( n=0; n<inst_num_limit; n++ ));
              do
                row_arr[$idx_row_char]=" "
                idx_row_char=$(( idx_row_char+1 ))
                echo -ne "\tidx_n="$idx_row_char
              done
      done    
    echo ${row_arr[*]}
    fi
  done
