### Kshitij Nigam - 2023202031
# SSD Lab Activity 2

## Question 1
To run the file:
```
chmod u+x 2023202031_q1.sh 
./2023202031_q1.sh
```

## Question 2
To run the file:
```
chmod u+x 2023202031_q2.sh 
./2023202031_q2.sh [Path To Directory]
```

## Question 3
To run the file:
```
chmod u+x 2023202031_q3.sh
./2023202031_q3.sh [Path To Directory]
```