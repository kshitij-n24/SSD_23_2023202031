#! /bin/bash

ls -l $1 | grep -e ^[-d]rwx-[-w]-[r-][w-]x