### Kshitij Nigam - 2023202031
# SSD Lab Activity 3

## Question 1

The SQL commands are separated as different files for different parts
such as 
2023202031_q1_A.sql, 2023202031_q1_B.sql and so on 

## Question 2

The SQL commands are separated as different files for different parts
such as 
2023202031_q2_A.sql, 2023202031_q2_B.sql and so on
 