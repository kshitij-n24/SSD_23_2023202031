# Software Systems Development
## Kshitij Nigam - 2023202031

This lab activity contains MERN app for TODO, in which there are login page, register page create todo page, pending todo page and completed todo page.

To run the code:
```
    cd client && npm install && npm run build
    cd ../server && npm install && npm run dev
```