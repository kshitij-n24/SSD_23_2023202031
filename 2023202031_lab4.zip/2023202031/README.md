### Kshitij Nigam - 2023202031
# SSD Lab Activity 4

---

## Question 1

This .sql file implements a division of two numbers using parameterized procedure.

## Question 2

This .sql file uses a procedure to find all the customers' names and cities whose Payment amount is greater than 5000.

## Question 3

This .sql file uses a cursor to find the names, countries and grades of the customers who have a Agent Code starting with A00.

*Assumption: The agent code provided in the parameter does not contain a % symbol but only the code such as 'A00'*
