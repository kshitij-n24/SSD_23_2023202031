#! /bin/bash

man whereis | grep -iB 1 "search for binaries"
