#! /bin/bash

ls $1 | grep -i f | grep -v cpp
