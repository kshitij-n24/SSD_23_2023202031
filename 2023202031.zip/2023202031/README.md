# The shell scripts for Software Systems Lab

Assumption:
For question 1, if the number of lines is even, then the {(n/2) + 1}th line

To run the scripts:

## Question 1
```
    chmod u+x 2023202031_q1.sh
    ./2023202031_q1.sh [Path to File]
```

## Question 2
```
    chmod u+x 2023202031_q2.sh
    ./2023202031_q2.sh [Path to Directory]
```

## Question 3
```
    chmod u+x 2023202031_q3.sh
    ./2023202031_q3.sh
```
